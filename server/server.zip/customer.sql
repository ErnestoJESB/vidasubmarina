/*
-- Query: SELECT * FROM customersdb.customer
LIMIT 0, 1000

-- Date: 2023-06-29 12:37
*/
INSERT INTO `` (`id`,`name`,`address`,`phone`,`type`,`name_image`,`data_image`) VALUES (10,'Jose','Cancún','32552','image/png','Agregar un tÃ­tulo (6).png',?);
INSERT INTO `` (`id`,`name`,`address`,`phone`,`type`,`name_image`,`data_image`) VALUES (11,'Sirve?','espero ','que sí','image/png','DiseÃ±o sin tÃ­tulo (7).png',?);
INSERT INTO `` (`id`,`name`,`address`,`phone`,`type`,`name_image`,`data_image`) VALUES (13,'Logo','hello','1234','image/png','logoMWOLD.png',?);
INSERT INTO `` (`id`,`name`,`address`,`phone`,`type`,`name_image`,`data_image`) VALUES (14,'edificio','nader','Este edificio se caracteriza por ','image/png','edificio.png',?);
INSERT INTO `` (`id`,`name`,`address`,`phone`,`type`,`name_image`,`data_image`) VALUES (15,'Lol','Cancun','84385965','image/jpeg','ejecutivo2.jpg',?);
INSERT INTO `` (`id`,`name`,`address`,`phone`,`type`,`name_image`,`data_image`) VALUES (16,'José Ernesto Soberano','C Jose Maria Bustamante','9932085583','image/jpeg','condominio-1.jpg',?);
INSERT INTO `` (`id`,`name`,`address`,`phone`,`type`,`name_image`,`data_image`) VALUES (17,'José Ernesto Soberano','C Jose Maria Bustamante M13 ','9932085583','image/jpeg','ejecutivo2.jpg',?);
